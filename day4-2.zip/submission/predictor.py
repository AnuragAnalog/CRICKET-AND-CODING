### Custom definitions and classes if any ###

import pickle
import pandas as pd

def predictRuns(testInput):
    # Load the data
    data = pd.read_csv('inputFile.csv')
    inni = data['innings'].values[0]
    dbfile = open('average.pkl', 'rb')
    db = pickle.load(dbfile)
    prediction = db[inni]
    ### Your Code Here ###
    return prediction
