### Custom definitions and classes if any ###

### The approach is simple, average of all the match's 6 overs.

import pickle

def predictRuns(testInput):
    dbfile = open('average.pkl', 'rb')
    db = pickle.load(dbfile)
    prediction = db['pred']
    ### Your Code Here ###
    return prediction
