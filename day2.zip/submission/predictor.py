### Custom definitions and classes if any ###

import pickle

def predictRuns(testInput):
    dbfile = open('average.pkl', 'rb')
    db = pickle.load(dbfile)
    prediction = db['pred']
    ### Your Code Here ###
    return prediction
